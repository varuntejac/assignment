package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RESTController {
	@Autowired
	TaskInterface task;
	@GetMapping(value="/task")
	//@RequestMapping(value="/task",method=RequestMethod.GET,produces= {"application/json","application/xml"})
	public Task getTask()
	{
		return task.getTask(120);
	}
	
	//@GetMapping(value="/listtask")
	@RequestMapping(value="/listtask",method=RequestMethod.GET,produces= {"application/json","application/xml"})
	public List<Task> getAllTasks()
	{
		return task.getAllTasks();
	}
	/*@GetMapping(value="/updatenote")
	//@RequestMapping(value="/updatenote",method=RequestMethod.GET,produces= {"application/json","application/xml"})
	public int getUpdateNotes()
	{
		return task.setNotesBookmark(1,"Task Contacts",true);
	}*/
	@GetMapping(value="/updatetask")
	//@RequestMapping(value="/updatetask",method=RequestMethod.GET,produces= {"application/json","application/xml"})
	public int getUpdate()
	{
		return task.setPriority(1,"High","Task details/dependencise/contacts",true);
	}
	
	@PostMapping(value= "/addtask", consumes = "application/json", produces = "application/json")
	public Task addTask(@RequestBody Task task1) throws Exception
	{
		task.addTask(task1);
		return task.getOneTasks();
		
	}



}
/*<dependency>
		<groupId>com.fasterxml.jackson.dataformat</groupId>
		<artifactId>jackson-dataformat-xml</artifactId>
		</dependency>*/