package com.example.demo;

import java.util.List;

public interface TaskInterface {
	public Task getTask(int Task_Id);
	public List<Task> getAllTasks();
	public int setPriority(int Task_Id,String Priority,String Notes,Boolean isBookmarked);
	//public int setNotesBookmark(int Task_Id,String Notes,Boolean isBookmarked);
	public Task addTask(Object object);
	public Task getOneTasks();
	
}
