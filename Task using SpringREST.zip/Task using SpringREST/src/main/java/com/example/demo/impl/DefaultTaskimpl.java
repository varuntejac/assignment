package com.example.demo.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

import com.example.demo.Task;
import com.example.demo.TaskInterface;
@SpringBootApplication
@Component
public class DefaultTaskimpl implements TaskInterface {

	DbConnection db=new DbConnection();
	Task task=null;
	
	int row=0;
	int row2=0;
	@Override
	public Task getTask(int Task_Id) {
		Task t=new Task();
		t.setTask_Id(120);
		t.setOwner_Id(5);
		t.setCreator_Id(9);
		t.setName("Sravani");
		t.setDescription("Nothing");
		t.setStatus("CivilEngineer");
		t.setPriority("nothing");
		t.setNotes("nothing");
		t.setIsBookmarked(true);
		t.setCreated_On(null);
		t.setStatusChanged_On(null);
		
		return t;
		
	}
	@Override 
	public List<Task> getAllTasks(){
	List<Task> taskList=new ArrayList<>();
	try {
		PreparedStatement cs1=db.getConnection().prepareStatement("select * from task ");
		
		ResultSet rs=cs1.executeQuery();
		while(rs.next()) {
			Task ts=new Task();
			ts.setTask_Id(rs.getInt(1));
			ts.setOwner_Id(rs.getInt(2));
			ts.setCreator_Id(rs.getInt(3));
			ts.setName(rs.getString(4));
			ts.setDescription(rs.getString(5));
			ts.setStatus(rs.getString(6));
			ts.setPriority(rs.getString(7));
			ts.setNotes(rs.getString(8));
			ts.setIsBookmarked(rs.getBoolean(9));
			ts.setCreated_On(rs.getTimestamp(10));
			ts.setStatusChanged_On(rs.getTimestamp(11));
			taskList.add(ts);
		}
	}catch(SQLException e) {e.printStackTrace();}
	
	return taskList;
	}
	/*public int setNotesBookmark(int Task_Id,String Notes,Boolean isBookmarked) {
		try {
			PreparedStatement cs2=db.getConnection().prepareStatement("update Task set Notes=?,isBookmarked=? where Task_Id=?");
			cs2.setString(1,Notes);
			cs2.setBoolean(2,isBookmarked);
			cs2.setInt(3,Task_Id);
			row=cs2.executeUpdate();
			System.out.println("this number of updated records  are "+row);
			db.closeConnection();
		}catch(SQLException e) {System.out.println(e);}
		return row;
		
	}*/
	public int setPriority(int Task_Id,String Priority,String Notes,Boolean isBookmarked)
	{
		
		try {
			PreparedStatement cs2=db.getConnection().prepareStatement("update Task set Priority=?,Notes=?,isBookmarked=?  where Task_Id=?");
			cs2.setString(1,Priority);
			cs2.setString(2,Notes);
			cs2.setBoolean(3,isBookmarked);
			cs2.setInt(4,Task_Id);
			row=cs2.executeUpdate();
			System.out.println("this number of updated records  are "+row);
			db.closeConnection();
		}catch(SQLException e) {System.out.println(e);}
		return row;
		
	}
	public Task addTask(Object object)
	{
		try {
			task=(Task)object;
			PreparedStatement cs= db.getConnection().prepareStatement
					("insert into TASK values(?,?,?,?,?,?,?,?,?)");
			cs.setInt(1,task.getTask_Id());
			/*cs.setInt(2, task.getOwner_Id());
			cs.setInt(3,task.getCreator_Id());*/
			cs.setString(2, task.getName());
			cs.setString(3, task.getDescription());
			cs.setString(4, task.getStatus());
			cs.setString(5, task.getPriority());
			cs.setString(6, task.getNotes());
			cs.setBoolean(7, task.getIsBookmarked());
			cs.setTimestamp(8, task.getCreated_On());
			cs.setTimestamp(9,task.getStatusChanged_On() );
			@SuppressWarnings("unused")
			int row3=cs.executeUpdate();
			db.closeConnection();
		}catch(SQLException e) {e.printStackTrace();}
		return task;
	}
	
	@Override 
	public Task getOneTasks(){
	try {
		PreparedStatement cs1=db.getConnection().prepareStatement("select * from task ");
		ResultSet rs=cs1.executeQuery();
		while(rs.next()) {
			Task ts=new Task();
			ts.setTask_Id(rs.getInt(1));
			ts.setOwner_Id(rs.getInt(2));
			ts.setCreator_Id(rs.getInt(3));
			ts.setName(rs.getString(4));
			ts.setDescription(rs.getString(5));
			ts.setStatus(rs.getString(6));
			ts.setPriority(rs.getString(7));
			ts.setNotes(rs.getString(8));
			ts.setIsBookmarked(rs.getBoolean(9));
			ts.setCreated_On(rs.getTimestamp(10));
			ts.setStatusChanged_On(rs.getTimestamp(11));
			
		}
	}catch(SQLException e) {e.printStackTrace();}
	
	return task;
	}

	
	

}
